import { Page } from "tns-core-modules/ui/page";
export declare function onAlbumsItemTap(args: any): void;
export declare function pageLoaded(args: any): void;
export declare function navigatedFrom(args: any): void;
export declare function done(args: any): void;
export declare function albumsPageFactory(): Page;
