module.exports = require('./lib/index');
