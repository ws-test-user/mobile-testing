export declare class NativeScriptCommonModule {
}
