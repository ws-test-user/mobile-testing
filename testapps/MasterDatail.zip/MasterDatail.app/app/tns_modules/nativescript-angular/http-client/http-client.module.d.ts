export declare class NativeScriptHttpClientModule {
}
