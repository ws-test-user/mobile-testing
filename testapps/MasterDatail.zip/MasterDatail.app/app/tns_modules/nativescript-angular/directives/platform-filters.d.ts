import { Device } from "tns-core-modules/platform";
export declare class AndroidFilterComponent {
    show: boolean;
    constructor(device: Device);
}
export declare class IosFilterComponent {
    show: boolean;
    constructor(device: Device);
}
