if (!console.group) {
    console.group = function () { };
}
if (!console.groupEnd) {
    console.groupEnd = function () { };
}
//# sourceMappingURL=console.js.map