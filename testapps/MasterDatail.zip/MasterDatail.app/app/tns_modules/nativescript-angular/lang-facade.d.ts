export declare function isPresent(obj: any): boolean;
export declare function isBlank(obj: any): boolean;
