Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var trace_1 = require("tns-core-modules/trace");
exports.CATEGORY = "detached-loader";
function log(message) {
    trace_1.write(message, exports.CATEGORY);
}
/**
 * Wrapper component used for loading components when navigating
 * It uses DetachedContainer as selector so that it is containerRef is not attached to
 * the visual tree.
 */
var DetachedLoader = /** @class */ (function () {
    function DetachedLoader(resolver, changeDetector, containerRef) {
        this.resolver = resolver;
        this.changeDetector = changeDetector;
        this.containerRef = containerRef;
    }
    DetachedLoader.prototype.loadInLocation = function (componentType) {
        var factory = this.resolver.resolveComponentFactory(componentType);
        var componentRef = this.containerRef.createComponent(factory, this.containerRef.length, this.containerRef.parentInjector);
        // Component is created, built may not be checked if we are loading
        // inside component with OnPush CD strategy. Mark us for check to be sure CD will reach us.
        // We are inside a promise here so no need for setTimeout - CD should trigger
        // after the promise.
        log("DetachedLoader.loadInLocation component loaded -> markForCheck");
        return Promise.resolve(componentRef);
    };
    DetachedLoader.prototype.detectChanges = function () {
        this.changeDetector.markForCheck();
    };
    // TODO: change this API -- async promises not needed here anymore.
    // TODO: change this API -- async promises not needed here anymore.
    DetachedLoader.prototype.loadComponent = 
    // TODO: change this API -- async promises not needed here anymore.
    function (componentType) {
        log("DetachedLoader.loadComponent");
        return this.loadInLocation(componentType);
    };
    DetachedLoader.prototype.loadWithFactory = function (factory) {
        return this.containerRef.createComponent(factory, this.containerRef.length, this.containerRef.parentInjector, null);
    };
    DetachedLoader.decorators = [
        { type: core_1.Component, args: [{
                    selector: "DetachedContainer",
                    template: "<Placeholder #loader></Placeholder>"
                },] },
    ];
    /** @nocollapse */
    DetachedLoader.ctorParameters = function () { return [
        { type: core_1.ComponentFactoryResolver, },
        { type: core_1.ChangeDetectorRef, },
        { type: core_1.ViewContainerRef, },
    ]; };
    return DetachedLoader;
}());
exports.DetachedLoader = DetachedLoader;
//# sourceMappingURL=detached-loader.js.map