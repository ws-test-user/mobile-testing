export declare function throwIfAlreadyLoaded(parentModule: any, moduleName: string): void;
