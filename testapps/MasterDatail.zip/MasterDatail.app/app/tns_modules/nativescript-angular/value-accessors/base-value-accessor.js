function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
// This file is only for compatibility with pre 4.4.0 releases.
// Please use "nativescript-angular/forms/value-accessors/base-value-accessor"
__export(require("../forms/value-accessors/base-value-accessor"));
//# sourceMappingURL=base-value-accessor.js.map