[Get started with Angular and NativeScript.](http://docs.nativescript.org/angular/start/introduction.html)
