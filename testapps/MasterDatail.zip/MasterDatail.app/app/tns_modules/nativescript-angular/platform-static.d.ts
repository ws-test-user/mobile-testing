import { AppOptions } from "./platform-common";
import { PlatformRef } from "@angular/core";
export declare function platformNativeScript(options?: AppOptions, extraProviders?: any[]): PlatformRef;
