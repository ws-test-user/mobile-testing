import { ContentView } from "tns-core-modules/ui/content-view";
import { ViewBase } from "tns-core-modules/ui/core/view/view";
export declare class AppHostView extends ContentView {
    ngAppRoot: ViewBase;
}
