Object.defineProperty(exports, "__esModule", { value: true });
var content_view_1 = require("tns-core-modules/ui/content-view");
var AppHostView = /** @class */ (function (_super) {
    __extends(AppHostView, _super);
    function AppHostView() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return AppHostView;
}(content_view_1.ContentView));
exports.AppHostView = AppHostView;
//# sourceMappingURL=app-host-view.js.map