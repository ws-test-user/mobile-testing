import { Compiler, SystemJsNgModuleLoader, SystemJsNgModuleLoaderConfig } from "@angular/core";
export declare class NSModuleFactoryLoader extends SystemJsNgModuleLoader {
    constructor(compiler: Compiler, config?: SystemJsNgModuleLoaderConfig);
}
