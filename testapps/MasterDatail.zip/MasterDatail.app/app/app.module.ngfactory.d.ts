/**
 * A dynamically generated module when compiled with AoT.
 */
export const AppModuleNgFactory: any;
