export class Config {
    static firebaseBucket = "gs://car-rental-b26b7.appspot.com/";
}
