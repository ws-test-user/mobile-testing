"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Config = /** @class */ (function () {
    function Config() {
    }
    Config.firebaseBucket = "gs://car-rental-b26b7.appspot.com/";
    return Config;
}());
exports.Config = Config;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlnLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiY29uZmlnLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUE7SUFBQTtJQUVBLENBQUM7SUFEVSxxQkFBYyxHQUFHLG9DQUFvQyxDQUFDO0lBQ2pFLGFBQUM7Q0FBQSxBQUZELElBRUM7QUFGWSx3QkFBTSIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjbGFzcyBDb25maWcge1xyXG4gICAgc3RhdGljIGZpcmViYXNlQnVja2V0ID0gXCJnczovL2Nhci1yZW50YWwtYjI2YjcuYXBwc3BvdC5jb20vXCI7XHJcbn1cclxuIl19