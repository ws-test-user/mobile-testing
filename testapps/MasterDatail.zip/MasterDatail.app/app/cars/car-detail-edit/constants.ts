
export const carClassList: Array<string> = [
    "Mini",
    "Economy",
    "Compact",
    "Standard",
    "Luxury"
];

export const carDoorList: Array<number> = [
    2,
    3,
    5
];

export const carSeatList: Array<string> = [
    "2",
    "4",
    "4 + 1",
    "6 + 1"
];

export const carTransmissionList: Array<string> = [
    "Manual",
    "Automatic"
];
