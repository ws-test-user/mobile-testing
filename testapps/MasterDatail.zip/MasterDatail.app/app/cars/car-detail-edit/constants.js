"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.carClassList = [
    "Mini",
    "Economy",
    "Compact",
    "Standard",
    "Luxury"
];
exports.carDoorList = [
    2,
    3,
    5
];
exports.carSeatList = [
    "2",
    "4",
    "4 + 1",
    "6 + 1"
];
exports.carTransmissionList = [
    "Manual",
    "Automatic"
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uc3RhbnRzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiY29uc3RhbnRzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQ2EsUUFBQSxZQUFZLEdBQWtCO0lBQ3ZDLE1BQU07SUFDTixTQUFTO0lBQ1QsU0FBUztJQUNULFVBQVU7SUFDVixRQUFRO0NBQ1gsQ0FBQztBQUVXLFFBQUEsV0FBVyxHQUFrQjtJQUN0QyxDQUFDO0lBQ0QsQ0FBQztJQUNELENBQUM7Q0FDSixDQUFDO0FBRVcsUUFBQSxXQUFXLEdBQWtCO0lBQ3RDLEdBQUc7SUFDSCxHQUFHO0lBQ0gsT0FBTztJQUNQLE9BQU87Q0FDVixDQUFDO0FBRVcsUUFBQSxtQkFBbUIsR0FBa0I7SUFDOUMsUUFBUTtJQUNSLFdBQVc7Q0FDZCxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmV4cG9ydCBjb25zdCBjYXJDbGFzc0xpc3Q6IEFycmF5PHN0cmluZz4gPSBbXHJcbiAgICBcIk1pbmlcIixcclxuICAgIFwiRWNvbm9teVwiLFxyXG4gICAgXCJDb21wYWN0XCIsXHJcbiAgICBcIlN0YW5kYXJkXCIsXHJcbiAgICBcIkx1eHVyeVwiXHJcbl07XHJcblxyXG5leHBvcnQgY29uc3QgY2FyRG9vckxpc3Q6IEFycmF5PG51bWJlcj4gPSBbXHJcbiAgICAyLFxyXG4gICAgMyxcclxuICAgIDVcclxuXTtcclxuXHJcbmV4cG9ydCBjb25zdCBjYXJTZWF0TGlzdDogQXJyYXk8c3RyaW5nPiA9IFtcclxuICAgIFwiMlwiLFxyXG4gICAgXCI0XCIsXHJcbiAgICBcIjQgKyAxXCIsXHJcbiAgICBcIjYgKyAxXCJcclxuXTtcclxuXHJcbmV4cG9ydCBjb25zdCBjYXJUcmFuc21pc3Npb25MaXN0OiBBcnJheTxzdHJpbmc+ID0gW1xyXG4gICAgXCJNYW51YWxcIixcclxuICAgIFwiQXV0b21hdGljXCJcclxuXTtcclxuIl19