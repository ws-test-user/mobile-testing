"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("nativescript-angular/router");
var dialogs_1 = require("ui/dialogs");
var car_edit_service_1 = require("../shared/car-edit.service");
var car_service_1 = require("../shared/car.service");
var constants_1 = require("./constants");
var CarDetailEditComponent = /** @class */ (function () {
    function CarDetailEditComponent(_carService, _carEditService, _pageRoute, _routerExtensions) {
        this._carService = _carService;
        this._carEditService = _carEditService;
        this._pageRoute = _pageRoute;
        this._routerExtensions = _routerExtensions;
        this._carClassOptions = [];
        this._carDoorOptions = [];
        this._carSeatOptions = [];
        this._carTransmissionOptions = [];
        this._isCarImageDirty = false;
        this._isUpdating = false;
    }
    CarDetailEditComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.initializeEditOptions();
        this._pageRoute.activatedRoute
            .switchMap(function (activatedRoute) { return activatedRoute.params; })
            .forEach(function (params) {
            var carId = params.id;
            _this._car = _this._carEditService.startEdit(carId);
        });
    };
    Object.defineProperty(CarDetailEditComponent.prototype, "isUpdating", {
        get: function () {
            return this._isUpdating;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CarDetailEditComponent.prototype, "car", {
        get: function () {
            return this._car;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CarDetailEditComponent.prototype, "pricePerDay", {
        get: function () {
            return this._car.price;
        },
        set: function (value) {
            // force iOS UISlider to work with discrete steps
            this._car.price = Math.round(value);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CarDetailEditComponent.prototype, "luggageValue", {
        get: function () {
            return this._car.luggage;
        },
        set: function (value) {
            // force iOS UISlider to work with discrete steps
            this._car.luggage = Math.round(value);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CarDetailEditComponent.prototype, "carClassOptions", {
        get: function () {
            return this._carClassOptions;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CarDetailEditComponent.prototype, "carDoorOptions", {
        get: function () {
            return this._carDoorOptions;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CarDetailEditComponent.prototype, "carSeatOptions", {
        get: function () {
            return this._carSeatOptions;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CarDetailEditComponent.prototype, "carTransmissionOptions", {
        get: function () {
            return this._carTransmissionOptions;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CarDetailEditComponent.prototype, "carImageUrl", {
        get: function () {
            return this._car.imageUrl;
        },
        set: function (value) {
            this._car.imageUrl = value;
            this._isCarImageDirty = true;
        },
        enumerable: true,
        configurable: true
    });
    CarDetailEditComponent.prototype.onCancelButtonTap = function () {
        this._routerExtensions.backToPreviousPage();
    };
    CarDetailEditComponent.prototype.onDoneButtonTap = function () {
        /* ***********************************************************
        * By design this app is set up to work with read-only sample data.
        * Follow the steps in the "Firebase database setup" section in app/readme.md file
        * and uncomment the code block below to make it editable.
        *************************************************************/
        var _this = this;
        /* ***********************************************************
        let queue = Promise.resolve();

        this._isUpdating = true;

        if (this._isCarImageDirty && this._car.imageUrl) {
            queue = queue
                .then(() => this._carService.uploadImage(this._car.imageStoragePath, this._car.imageUrl))
                .then((uploadedFile: any) => {
                    this._car.imageUrl = uploadedFile.url;
                });
        }

        queue.then(() => this._carService.update(this._car))
            .then(() => {
                this._isUpdating = false;
                this._routerExtensions.navigate(["/cars"], {
                    clearHistory: true,
                    animated: true,
                    transition: {
                        name: "slideBottom",
                        duration: 200,
                        curve: "ease"
                    }
                });
            })
            .catch((errorMessage: any) => {
                this._isUpdating = false;
                alert({ title: "Oops!", message: "Something went wrong. Please try again.", okButtonText: "Ok" });
            });
        *************************************************************/
        /* ***********************************************************
        * Comment out the code block below if you made the app editable.
        *************************************************************/
        var readOnlyMessage = "Check out the \"Firebase database setup\" section in the readme file to make it editable."; // tslint:disable-line:max-line-length
        var queue = Promise.resolve();
        queue.then(function () { return dialogs_1.alert({ title: "Read-Only Template!", message: readOnlyMessage, okButtonText: "Ok" }); })
            .then(function () { return _this._routerExtensions.navigate(["/cars"], {
            clearHistory: true,
            animated: true,
            transition: {
                name: "slideBottom",
                duration: 200,
                curve: "ease"
            }
        }); });
    };
    CarDetailEditComponent.prototype.initializeEditOptions = function () {
        for (var _i = 0, carClassList_1 = constants_1.carClassList; _i < carClassList_1.length; _i++) {
            var classItem = carClassList_1[_i];
            this._carClassOptions.push(classItem);
        }
        for (var _a = 0, carDoorList_1 = constants_1.carDoorList; _a < carDoorList_1.length; _a++) {
            var doorItem = carDoorList_1[_a];
            this._carDoorOptions.push(doorItem);
        }
        for (var _b = 0, carSeatList_1 = constants_1.carSeatList; _b < carSeatList_1.length; _b++) {
            var seatItem = carSeatList_1[_b];
            this._carSeatOptions.push(seatItem);
        }
        for (var _c = 0, carTransmissionList_1 = constants_1.carTransmissionList; _c < carTransmissionList_1.length; _c++) {
            var transmissionItem = carTransmissionList_1[_c];
            this._carTransmissionOptions.push(transmissionItem);
        }
    };
    CarDetailEditComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "CarDetailEdit",
            templateUrl: "./car-detail-edit.component.html",
            styleUrls: ["./car-detail-edit.component.scss"]
        }),
        __metadata("design:paramtypes", [car_service_1.CarService,
            car_edit_service_1.CarEditService,
            router_1.PageRoute,
            router_1.RouterExtensions])
    ], CarDetailEditComponent);
    return CarDetailEditComponent;
}());
exports.CarDetailEditComponent = CarDetailEditComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FyLWRldGFpbC1lZGl0LmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImNhci1kZXRhaWwtZWRpdC5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxzQ0FBa0Q7QUFDbEQsc0RBQTBFO0FBQzFFLHNDQUFtQztBQUVuQywrREFBNEQ7QUFFNUQscURBQW1EO0FBQ25ELHlDQUEwRjtBQVExRjtJQVNJLGdDQUNZLFdBQXVCLEVBQ3ZCLGVBQStCLEVBQy9CLFVBQXFCLEVBQ3JCLGlCQUFtQztRQUhuQyxnQkFBVyxHQUFYLFdBQVcsQ0FBWTtRQUN2QixvQkFBZSxHQUFmLGVBQWUsQ0FBZ0I7UUFDL0IsZUFBVSxHQUFWLFVBQVUsQ0FBVztRQUNyQixzQkFBaUIsR0FBakIsaUJBQWlCLENBQWtCO1FBWHZDLHFCQUFnQixHQUFrQixFQUFFLENBQUM7UUFDckMsb0JBQWUsR0FBa0IsRUFBRSxDQUFDO1FBQ3BDLG9CQUFlLEdBQWtCLEVBQUUsQ0FBQztRQUNwQyw0QkFBdUIsR0FBa0IsRUFBRSxDQUFDO1FBQzVDLHFCQUFnQixHQUFZLEtBQUssQ0FBQztRQUNsQyxnQkFBVyxHQUFZLEtBQUssQ0FBQztJQU9qQyxDQUFDO0lBRUwseUNBQVEsR0FBUjtRQUFBLGlCQVVDO1FBVEcsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFFN0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjO2FBQ3pCLFNBQVMsQ0FBQyxVQUFDLGNBQWMsSUFBSyxPQUFBLGNBQWMsQ0FBQyxNQUFNLEVBQXJCLENBQXFCLENBQUM7YUFDcEQsT0FBTyxDQUFDLFVBQUMsTUFBTTtZQUNaLElBQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUM7WUFFeEIsS0FBSSxDQUFDLElBQUksR0FBRyxLQUFJLENBQUMsZUFBZSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN0RCxDQUFDLENBQUMsQ0FBQztJQUNYLENBQUM7SUFFRCxzQkFBSSw4Q0FBVTthQUFkO1lBQ0ksTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7UUFDNUIsQ0FBQzs7O09BQUE7SUFFRCxzQkFBSSx1Q0FBRzthQUFQO1lBQ0ksTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDckIsQ0FBQzs7O09BQUE7SUFFRCxzQkFBSSwrQ0FBVzthQUFmO1lBQ0ksTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQzNCLENBQUM7YUFFRCxVQUFnQixLQUFhO1lBQ3pCLGlEQUFpRDtZQUNqRCxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3hDLENBQUM7OztPQUxBO0lBT0Qsc0JBQUksZ0RBQVk7YUFBaEI7WUFDSSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7UUFDN0IsQ0FBQzthQUVELFVBQWlCLEtBQWE7WUFDMUIsaURBQWlEO1lBQ2pELElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDMUMsQ0FBQzs7O09BTEE7SUFPRCxzQkFBSSxtREFBZTthQUFuQjtZQUNJLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7UUFDakMsQ0FBQzs7O09BQUE7SUFFRCxzQkFBSSxrREFBYzthQUFsQjtZQUNJLE1BQU0sQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDO1FBQ2hDLENBQUM7OztPQUFBO0lBRUQsc0JBQUksa0RBQWM7YUFBbEI7WUFDSSxNQUFNLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQztRQUNoQyxDQUFDOzs7T0FBQTtJQUVELHNCQUFJLDBEQUFzQjthQUExQjtZQUNJLE1BQU0sQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUM7UUFDeEMsQ0FBQzs7O09BQUE7SUFFRCxzQkFBSSwrQ0FBVzthQUFmO1lBQ0ksTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO1FBQzlCLENBQUM7YUFFRCxVQUFnQixLQUFhO1lBQ3pCLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztZQUMzQixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO1FBQ2pDLENBQUM7OztPQUxBO0lBT0Qsa0RBQWlCLEdBQWpCO1FBQ0ksSUFBSSxDQUFDLGlCQUFpQixDQUFDLGtCQUFrQixFQUFFLENBQUM7SUFDaEQsQ0FBQztJQUVELGdEQUFlLEdBQWY7UUFDSTs7OztzRUFJOEQ7UUFMbEUsaUJBc0RDO1FBL0NHOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7c0VBOEI4RDtRQUU5RDs7c0VBRThEO1FBQzlELElBQU0sZUFBZSxHQUFHLDJGQUEyRixDQUFDLENBQUMsc0NBQXNDO1FBQzNKLElBQU0sS0FBSyxHQUFHLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUNoQyxLQUFLLENBQUMsSUFBSSxDQUFDLGNBQU0sT0FBQSxlQUFLLENBQUMsRUFBRSxLQUFLLEVBQUUscUJBQXFCLEVBQUUsT0FBTyxFQUFFLGVBQWUsRUFBRSxZQUFZLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBckYsQ0FBcUYsQ0FBQzthQUNsRyxJQUFJLENBQUMsY0FBTSxPQUFBLEtBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUNuRCxZQUFZLEVBQUUsSUFBSTtZQUNsQixRQUFRLEVBQUUsSUFBSTtZQUNkLFVBQVUsRUFBRTtnQkFDUixJQUFJLEVBQUUsYUFBYTtnQkFDbkIsUUFBUSxFQUFFLEdBQUc7Z0JBQ2IsS0FBSyxFQUFFLE1BQU07YUFDaEI7U0FDSixDQUFDLEVBUlUsQ0FRVixDQUFDLENBQUM7SUFDWixDQUFDO0lBRU8sc0RBQXFCLEdBQTdCO1FBQ0ksR0FBRyxDQUFDLENBQW9CLFVBQVksRUFBWixpQkFBQSx3QkFBWSxFQUFaLDBCQUFZLEVBQVosSUFBWTtZQUEvQixJQUFNLFNBQVMscUJBQUE7WUFDaEIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUN6QztRQUVELEdBQUcsQ0FBQyxDQUFtQixVQUFXLEVBQVgsZ0JBQUEsdUJBQVcsRUFBWCx5QkFBVyxFQUFYLElBQVc7WUFBN0IsSUFBTSxRQUFRLG9CQUFBO1lBQ2YsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDdkM7UUFFRCxHQUFHLENBQUMsQ0FBbUIsVUFBVyxFQUFYLGdCQUFBLHVCQUFXLEVBQVgseUJBQVcsRUFBWCxJQUFXO1lBQTdCLElBQU0sUUFBUSxvQkFBQTtZQUNmLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQ3ZDO1FBRUQsR0FBRyxDQUFDLENBQTJCLFVBQW1CLEVBQW5CLHdCQUFBLCtCQUFtQixFQUFuQixpQ0FBbUIsRUFBbkIsSUFBbUI7WUFBN0MsSUFBTSxnQkFBZ0IsNEJBQUE7WUFDdkIsSUFBSSxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1NBQ3ZEO0lBQ0wsQ0FBQztJQTNKUSxzQkFBc0I7UUFObEMsZ0JBQVMsQ0FBQztZQUNQLFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRTtZQUNuQixRQUFRLEVBQUUsZUFBZTtZQUN6QixXQUFXLEVBQUUsa0NBQWtDO1lBQy9DLFNBQVMsRUFBRSxDQUFDLGtDQUFrQyxDQUFDO1NBQ2xELENBQUM7eUNBVzJCLHdCQUFVO1lBQ04saUNBQWM7WUFDbkIsa0JBQVM7WUFDRix5QkFBZ0I7T0FidEMsc0JBQXNCLENBNEpsQztJQUFELDZCQUFDO0NBQUEsQUE1SkQsSUE0SkM7QUE1Slksd0RBQXNCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xyXG5pbXBvcnQgeyBQYWdlUm91dGUsIFJvdXRlckV4dGVuc2lvbnMgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFuZ3VsYXIvcm91dGVyXCI7XHJcbmltcG9ydCB7IGFsZXJ0IH0gZnJvbSBcInVpL2RpYWxvZ3NcIjtcclxuXHJcbmltcG9ydCB7IENhckVkaXRTZXJ2aWNlIH0gZnJvbSBcIi4uL3NoYXJlZC9jYXItZWRpdC5zZXJ2aWNlXCI7XHJcbmltcG9ydCB7IENhciB9IGZyb20gXCIuLi9zaGFyZWQvY2FyLm1vZGVsXCI7XHJcbmltcG9ydCB7IENhclNlcnZpY2UgfSBmcm9tIFwiLi4vc2hhcmVkL2Nhci5zZXJ2aWNlXCI7XHJcbmltcG9ydCB7IGNhckNsYXNzTGlzdCwgY2FyRG9vckxpc3QsIGNhclNlYXRMaXN0LCBjYXJUcmFuc21pc3Npb25MaXN0IH0gZnJvbSBcIi4vY29uc3RhbnRzXCI7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIG1vZHVsZUlkOiBtb2R1bGUuaWQsXHJcbiAgICBzZWxlY3RvcjogXCJDYXJEZXRhaWxFZGl0XCIsXHJcbiAgICB0ZW1wbGF0ZVVybDogXCIuL2Nhci1kZXRhaWwtZWRpdC5jb21wb25lbnQuaHRtbFwiLFxyXG4gICAgc3R5bGVVcmxzOiBbXCIuL2Nhci1kZXRhaWwtZWRpdC5jb21wb25lbnQuc2Nzc1wiXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgQ2FyRGV0YWlsRWRpdENvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBwcml2YXRlIF9jYXI6IENhcjtcclxuICAgIHByaXZhdGUgX2NhckNsYXNzT3B0aW9uczogQXJyYXk8c3RyaW5nPiA9IFtdO1xyXG4gICAgcHJpdmF0ZSBfY2FyRG9vck9wdGlvbnM6IEFycmF5PG51bWJlcj4gPSBbXTtcclxuICAgIHByaXZhdGUgX2NhclNlYXRPcHRpb25zOiBBcnJheTxzdHJpbmc+ID0gW107XHJcbiAgICBwcml2YXRlIF9jYXJUcmFuc21pc3Npb25PcHRpb25zOiBBcnJheTxzdHJpbmc+ID0gW107XHJcbiAgICBwcml2YXRlIF9pc0NhckltYWdlRGlydHk6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX2lzVXBkYXRpbmc6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9jYXJTZXJ2aWNlOiBDYXJTZXJ2aWNlLFxyXG4gICAgICAgIHByaXZhdGUgX2NhckVkaXRTZXJ2aWNlOiBDYXJFZGl0U2VydmljZSxcclxuICAgICAgICBwcml2YXRlIF9wYWdlUm91dGU6IFBhZ2VSb3V0ZSxcclxuICAgICAgICBwcml2YXRlIF9yb3V0ZXJFeHRlbnNpb25zOiBSb3V0ZXJFeHRlbnNpb25zXHJcbiAgICApIHsgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuaW5pdGlhbGl6ZUVkaXRPcHRpb25zKCk7XHJcblxyXG4gICAgICAgIHRoaXMuX3BhZ2VSb3V0ZS5hY3RpdmF0ZWRSb3V0ZVxyXG4gICAgICAgICAgICAuc3dpdGNoTWFwKChhY3RpdmF0ZWRSb3V0ZSkgPT4gYWN0aXZhdGVkUm91dGUucGFyYW1zKVxyXG4gICAgICAgICAgICAuZm9yRWFjaCgocGFyYW1zKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBjYXJJZCA9IHBhcmFtcy5pZDtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLl9jYXIgPSB0aGlzLl9jYXJFZGl0U2VydmljZS5zdGFydEVkaXQoY2FySWQpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBnZXQgaXNVcGRhdGluZygpOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5faXNVcGRhdGluZztcclxuICAgIH1cclxuXHJcbiAgICBnZXQgY2FyKCk6IENhciB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NhcjtcclxuICAgIH1cclxuXHJcbiAgICBnZXQgcHJpY2VQZXJEYXkoKTogbnVtYmVyIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fY2FyLnByaWNlO1xyXG4gICAgfVxyXG5cclxuICAgIHNldCBwcmljZVBlckRheSh2YWx1ZTogbnVtYmVyKSB7XHJcbiAgICAgICAgLy8gZm9yY2UgaU9TIFVJU2xpZGVyIHRvIHdvcmsgd2l0aCBkaXNjcmV0ZSBzdGVwc1xyXG4gICAgICAgIHRoaXMuX2Nhci5wcmljZSA9IE1hdGgucm91bmQodmFsdWUpO1xyXG4gICAgfVxyXG5cclxuICAgIGdldCBsdWdnYWdlVmFsdWUoKTogbnVtYmVyIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fY2FyLmx1Z2dhZ2U7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0IGx1Z2dhZ2VWYWx1ZSh2YWx1ZTogbnVtYmVyKSB7XHJcbiAgICAgICAgLy8gZm9yY2UgaU9TIFVJU2xpZGVyIHRvIHdvcmsgd2l0aCBkaXNjcmV0ZSBzdGVwc1xyXG4gICAgICAgIHRoaXMuX2Nhci5sdWdnYWdlID0gTWF0aC5yb3VuZCh2YWx1ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0IGNhckNsYXNzT3B0aW9ucygpOiBBcnJheTxzdHJpbmc+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fY2FyQ2xhc3NPcHRpb25zO1xyXG4gICAgfVxyXG5cclxuICAgIGdldCBjYXJEb29yT3B0aW9ucygpOiBBcnJheTxudW1iZXI+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fY2FyRG9vck9wdGlvbnM7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0IGNhclNlYXRPcHRpb25zKCk6IEFycmF5PHN0cmluZz4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9jYXJTZWF0T3B0aW9ucztcclxuICAgIH1cclxuXHJcbiAgICBnZXQgY2FyVHJhbnNtaXNzaW9uT3B0aW9ucygpOiBBcnJheTxzdHJpbmc+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fY2FyVHJhbnNtaXNzaW9uT3B0aW9ucztcclxuICAgIH1cclxuXHJcbiAgICBnZXQgY2FySW1hZ2VVcmwoKTogc3RyaW5nIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fY2FyLmltYWdlVXJsO1xyXG4gICAgfVxyXG5cclxuICAgIHNldCBjYXJJbWFnZVVybCh2YWx1ZTogc3RyaW5nKSB7XHJcbiAgICAgICAgdGhpcy5fY2FyLmltYWdlVXJsID0gdmFsdWU7XHJcbiAgICAgICAgdGhpcy5faXNDYXJJbWFnZURpcnR5ID0gdHJ1ZTtcclxuICAgIH1cclxuXHJcbiAgICBvbkNhbmNlbEJ1dHRvblRhcCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9yb3V0ZXJFeHRlbnNpb25zLmJhY2tUb1ByZXZpb3VzUGFnZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uRG9uZUJ1dHRvblRhcCgpOiB2b2lkIHtcclxuICAgICAgICAvKiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxyXG4gICAgICAgICogQnkgZGVzaWduIHRoaXMgYXBwIGlzIHNldCB1cCB0byB3b3JrIHdpdGggcmVhZC1vbmx5IHNhbXBsZSBkYXRhLlxyXG4gICAgICAgICogRm9sbG93IHRoZSBzdGVwcyBpbiB0aGUgXCJGaXJlYmFzZSBkYXRhYmFzZSBzZXR1cFwiIHNlY3Rpb24gaW4gYXBwL3JlYWRtZS5tZCBmaWxlXHJcbiAgICAgICAgKiBhbmQgdW5jb21tZW50IHRoZSBjb2RlIGJsb2NrIGJlbG93IHRvIG1ha2UgaXQgZWRpdGFibGUuXHJcbiAgICAgICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcbiAgICAgICAgLyogKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuICAgICAgICBsZXQgcXVldWUgPSBQcm9taXNlLnJlc29sdmUoKTtcclxuXHJcbiAgICAgICAgdGhpcy5faXNVcGRhdGluZyA9IHRydWU7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLl9pc0NhckltYWdlRGlydHkgJiYgdGhpcy5fY2FyLmltYWdlVXJsKSB7XHJcbiAgICAgICAgICAgIHF1ZXVlID0gcXVldWVcclxuICAgICAgICAgICAgICAgIC50aGVuKCgpID0+IHRoaXMuX2NhclNlcnZpY2UudXBsb2FkSW1hZ2UodGhpcy5fY2FyLmltYWdlU3RvcmFnZVBhdGgsIHRoaXMuX2Nhci5pbWFnZVVybCkpXHJcbiAgICAgICAgICAgICAgICAudGhlbigodXBsb2FkZWRGaWxlOiBhbnkpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9jYXIuaW1hZ2VVcmwgPSB1cGxvYWRlZEZpbGUudXJsO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBxdWV1ZS50aGVuKCgpID0+IHRoaXMuX2NhclNlcnZpY2UudXBkYXRlKHRoaXMuX2NhcikpXHJcbiAgICAgICAgICAgIC50aGVuKCgpID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2lzVXBkYXRpbmcgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3JvdXRlckV4dGVuc2lvbnMubmF2aWdhdGUoW1wiL2NhcnNcIl0sIHtcclxuICAgICAgICAgICAgICAgICAgICBjbGVhckhpc3Rvcnk6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgYW5pbWF0ZWQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbjoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBcInNsaWRlQm90dG9tXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGR1cmF0aW9uOiAyMDAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1cnZlOiBcImVhc2VcIlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAuY2F0Y2goKGVycm9yTWVzc2FnZTogYW55KSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9pc1VwZGF0aW5nID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICBhbGVydCh7IHRpdGxlOiBcIk9vcHMhXCIsIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmcuIFBsZWFzZSB0cnkgYWdhaW4uXCIsIG9rQnV0dG9uVGV4dDogXCJPa1wiIH0pO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG5cclxuICAgICAgICAvKiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxyXG4gICAgICAgICogQ29tbWVudCBvdXQgdGhlIGNvZGUgYmxvY2sgYmVsb3cgaWYgeW91IG1hZGUgdGhlIGFwcCBlZGl0YWJsZS5cclxuICAgICAgICAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgICAgIGNvbnN0IHJlYWRPbmx5TWVzc2FnZSA9IFwiQ2hlY2sgb3V0IHRoZSBcXFwiRmlyZWJhc2UgZGF0YWJhc2Ugc2V0dXBcXFwiIHNlY3Rpb24gaW4gdGhlIHJlYWRtZSBmaWxlIHRvIG1ha2UgaXQgZWRpdGFibGUuXCI7IC8vIHRzbGludDpkaXNhYmxlLWxpbmU6bWF4LWxpbmUtbGVuZ3RoXHJcbiAgICAgICAgY29uc3QgcXVldWUgPSBQcm9taXNlLnJlc29sdmUoKTtcclxuICAgICAgICBxdWV1ZS50aGVuKCgpID0+IGFsZXJ0KHsgdGl0bGU6IFwiUmVhZC1Pbmx5IFRlbXBsYXRlIVwiLCBtZXNzYWdlOiByZWFkT25seU1lc3NhZ2UsIG9rQnV0dG9uVGV4dDogXCJPa1wiIH0pKVxyXG4gICAgICAgICAgICAudGhlbigoKSA9PiB0aGlzLl9yb3V0ZXJFeHRlbnNpb25zLm5hdmlnYXRlKFtcIi9jYXJzXCJdLCB7XHJcbiAgICAgICAgICAgICAgICBjbGVhckhpc3Rvcnk6IHRydWUsXHJcbiAgICAgICAgICAgICAgICBhbmltYXRlZDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgIHRyYW5zaXRpb246IHtcclxuICAgICAgICAgICAgICAgICAgICBuYW1lOiBcInNsaWRlQm90dG9tXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgZHVyYXRpb246IDIwMCxcclxuICAgICAgICAgICAgICAgICAgICBjdXJ2ZTogXCJlYXNlXCJcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSkpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgaW5pdGlhbGl6ZUVkaXRPcHRpb25zKCk6IHZvaWQge1xyXG4gICAgICAgIGZvciAoY29uc3QgY2xhc3NJdGVtIG9mIGNhckNsYXNzTGlzdCkge1xyXG4gICAgICAgICAgICB0aGlzLl9jYXJDbGFzc09wdGlvbnMucHVzaChjbGFzc0l0ZW0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZm9yIChjb25zdCBkb29ySXRlbSBvZiBjYXJEb29yTGlzdCkge1xyXG4gICAgICAgICAgICB0aGlzLl9jYXJEb29yT3B0aW9ucy5wdXNoKGRvb3JJdGVtKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGZvciAoY29uc3Qgc2VhdEl0ZW0gb2YgY2FyU2VhdExpc3QpIHtcclxuICAgICAgICAgICAgdGhpcy5fY2FyU2VhdE9wdGlvbnMucHVzaChzZWF0SXRlbSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBmb3IgKGNvbnN0IHRyYW5zbWlzc2lvbkl0ZW0gb2YgY2FyVHJhbnNtaXNzaW9uTGlzdCkge1xyXG4gICAgICAgICAgICB0aGlzLl9jYXJUcmFuc21pc3Npb25PcHRpb25zLnB1c2godHJhbnNtaXNzaW9uSXRlbSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ==